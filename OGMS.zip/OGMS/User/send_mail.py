from django.core.mail import send_mail
import time

def send_email(mail=None):
    
    send_mail(
    'Approve Connection',
    'Your Gas Connection is Approved',
    'vchudasma1997@gmail.com',
    mail,
    fail_silently=False)