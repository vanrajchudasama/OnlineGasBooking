from django.db import models
import datetime
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models.signals import post_save
from django.dispatch import receiver
import os
from . import send_mail
from twilio.rest import Client
from django.conf import settings
# Create your models here.

class Users(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE,parent_link=False)
    mobile = models.BigIntegerField()
    class Meta:
        verbose_name_plural = "User Profile"

class Agency(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE,parent_link=False)
    agency_name = models.CharField(max_length=150,default='')
    
status = (  ('pending','Pending'),
            ('approved','Approved'),
            ('canceled','Canceled'))
cylinder_choice= (
('14.2','14.2 Kg'),
('5','5Kg')
)
class Connection(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    gender = models.CharField(max_length=20,default='')
    dob = models.DateField()
    relative = models.CharField(max_length=50,default='')
    ffname = models.CharField(max_length=50,default='')
    fmname = models.CharField(max_length=50,default='')
    flname = models.CharField(max_length=50,default='')

    mfname = models.CharField(max_length=50,default='')
    mmname = models.CharField(max_length=50,default='')
    mlname =models.CharField(max_length=50,default='')
    costomer_no = models.CharField(max_length=50,default='')

    status = models.CharField(max_length=30,choices=status,default='pending')
    def save(self, *args, **kwargs): 
        self.con=self.status
        if self.con == 'approved' :
           
            client = Client(settings.ACCOUNT_SID, settings.AUTH_TOKEN)
            mobile_no=Users.objects.get(user_id=self.user)
            user_email=User.objects.get(id=mobile_no.user_id)
           
            send_mail.send_email([user_email.email])
            message = client.messages.create(
                     body="your gas connection is approved ",
                     from_='+12059647948',
                     to='+91'+str(mobile_no.mobile)
                 )

           
           
        super(Connection, self).save(*args, **kwargs) 
  
    class Meta:
        verbose_name_plural = "User Gas Connection"
class Address(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    city = models.CharField(max_length=50,default='')
    district = models.CharField(max_length=50,default='')
    state = models.CharField(max_length=50,default='')
    pincode = models.CharField(max_length=50,default='')
    country = models.CharField(max_length=50,default='')
    address = models.CharField(max_length=100,default='')
    class Meta:
        verbose_name_plural = "User Address"
class Document(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    aadhar_no = models.CharField(max_length=50)
    aadhar_image = models.ImageField(upload_to='user_document/%Y-%m')
    rationcard_no = models.CharField(max_length=50)
    rationcard_image = models.ImageField(upload_to='user_document/%Y-%m')
    class Meta:
        verbose_name_plural = "User Documents"

cylinder_status=(
    ('confirm','Confirm'),
    ('ontheway','On The Way'),
    ('delivered','Delivered')
)
class Booking(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    cylinder_type = models.CharField(max_length=50,choices=cylinder_choice,default='5')
    price = models.IntegerField()
    book_date=models.DateField(default=datetime.date.today())
    status = models.CharField(max_length=30,choices=status,default='pending')
    class Meta:
        verbose_name_plural = "Gas Booking"
p_type=(('cashondelivery','Cash on Delivery'),)
class Payment(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    payment_type=models.CharField(max_length=50,choices=p_type,default='cashondelivery')
    amount=models.IntegerField()
    transaction_date=models.DateField(default=datetime.date.today())
    cylinder_type = models.CharField(max_length=50)
    class Meta:
        verbose_name_plural = "Transactions"