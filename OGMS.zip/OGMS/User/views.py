from django.shortcuts import render,HttpResponseRedirect
from django.http import HttpResponse
from django.contrib import auth
from django.contrib.auth.decorators import login_required,permission_required
from .form import UserForm,LoginForm,ProfileForm,ChangepasswordForm,UserUpdateForm,ProfileUpdateForm
from .models import Users
from django.contrib.auth.models import User
from django.contrib import messages
from django.core.mail import send_mail


def register_type(request):
    if request.method == 'POST':
        reg_type=request.POST.get('reg_type')
        print(reg_type)
        if reg_type=='0':
            return HttpResponseRedirect('/user/registration/')
        else:
            return HttpResponseRedirect('/user/login/')
    return render(request,'user/registertype.html')

def error_404_view(request, exception):
    data = {"name": "ThePythonDjango.com"}
    return render(request,'user/error_404.html', data)
@login_required(login_url='/user/login/')
# @permission_required('')
def home(request):
    if request.user.is_authenticated:
        return render(request,'user/index.html')
    else:
        return HttpResponseRedirect('/user/login')
    
def register(request):
    if 'user' in request.session:
        return HttpResponseRedirect('/user') 
    if request.method == 'POST':
        uf = UserForm(request.POST)
        pf = ProfileForm(request.POST)
        if uf.is_valid() and pf.is_valid():

            # fname=uf.cleaned_data['first_name']
            # lname=uf.cleaned_data['last_name']
            # username=uf.cleaned_data['username']
            # email=uf.cleaned_data['email']
            mobile=pf.cleaned_data['mobile']
            # password=uf.cleaned_data['password2']
            user = uf.save()
            profile = Users.objects.create(user=user,mobile=mobile)
            
               # c=User(first_name=fname,last_name=lname,email=email,mobile=mobile,password=password)
                # c.save()
            uf = UserForm()
            pf = ProfileForm()
            messages.add_message(request,messages.INFO,'Successfully Register...!')    
            return HttpResponseRedirect('/user/login/')
    else:
        uf = UserForm()
        pf = ProfileForm()
    return render(request,'user/register.html',{'form':uf,'pf':pf})

def user_login(request):
    # if 'user' in request.session:
    #     return HttpResponseRedirect('/User')
    if request.method == 'POST':
        l = LoginForm(request.POST)
        if l.is_valid():
            user=auth.authenticate(username=request.POST['username'],password=request.POST['password'])
            if user is not None:
                auth.login(request,user)
                return HttpResponseRedirect('/user')
            else:
                messages.add_message(request,messages.WARNING,'Invalid Login credentials...!')
            # username = l.cleaned_data['mobile']
            # password  =  make_password(l.cleaned_data['password'])
            # try:
            #     user = User.objects.get(mobile=username)
            #     User.objects.get(password=password)
            # except (User.DoesNotExist):
            #     print('Login success')
            #     request.session['user']=username
            #     return HttpResponseRedirect('/User')
            # else:
            #     print('Login unsuccess')
    else:
        l = LoginForm()
    return render(request,'user/login.html',{'form':l})
@login_required(login_url='/user/login/')   
def user_logout(request):
    auth.logout(request)
    # if 'user' in request.session:
    #     del request.session['user']
    return HttpResponseRedirect('/user/login')
    # else:
    #     return HttpResponseRedirect('/User')
@login_required(login_url='/user/login/') 
def change_password(request):
    if request.user.is_authenticated:

        if request.method == 'POST':
            form = ChangepasswordForm(instance=request.user,data=request.POST)
            if form.is_valid():
                form.save()
                auth.update_session_auth_hash(request,form.user)
                messages.success(request,'Password change successfuly..!')
                return HttpResponseRedirect('/user/changepassword/')
        else:
            form = ChangepasswordForm(user=request.user)
        return render(request,'user/change_password.html',{'form':form})
    else:
        return HttpResponseRedirect('/user/login/')

@login_required(login_url='/user/login/')
def profile(request):
    return render(request,'user/profile.html')

def update_profile(request):
    if request.user.is_authenticated:
        
        if request.method == 'POST':
            
            mobile = Users.objects.get(user=request.user)
            p_form=ProfileUpdateForm(request.POST,instance=mobile)
            form = UserUpdateForm(request.POST,instance=request.user)
            
            if form.is_valid() and p_form.is_valid():
                messages.success(request,'Your profile update success..!')
                p_form.save()
                form.save()
        else:
            form = UserUpdateForm(instance=request.user)
            mobile = Users.objects.get(user=request.user)
            p_form = ProfileUpdateForm(initial={'mobile':mobile.mobile})
        return render(request,'user/profile.html',{'form':form,'pform':p_form})
    else:
        
        return HttpResponseRedirect('/user/login/')

def send_mail_(request):
    send_mail(
    'Approve Connection',
    'Your Gas Connection is Approved',
    'vchudasma1997@gmail.com',
    ['chudasamavanraj4@gmail.com'],
    fail_silently=False)
    return render(request,'user/send_mail.html')