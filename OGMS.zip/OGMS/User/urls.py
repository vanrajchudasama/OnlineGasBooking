from django.urls import path
from . import views,connection

from django.contrib.auth import views as auth_views
app_name='user'
urlpatterns=[
    path('',views.home,name='user_home'),
    path('regtype/',views.register_type,name='reg_type'),
    path('registration/',views.register,name="user_register"),
    path('login/',views.user_login,name="user_login"),
    path('logout/',views.user_logout,name="user_logout"),
    path('changepassword/',views.change_password,name="change_password"),
    path('profile/',views.update_profile,name="profile"),
    path('profile/update',views.update_profile,name="profile_update"),

    path('connection/',connection.newconnection,name='newconnection'),
    # path('connection/doc',connection.document_upload,name='connectiondoc'),
    path('bookcylinder/',connection.cylinderbook,name='bookcylinder'),
    path('bookcylinderhistrory/',connection.cylinderbookhistory,name='bookcylinder_history'),
    path('booke/',connection.cylinderbookdetail,name='details'),
    path('cancelrequest/<int:id>',connection.cylindercancel,name='cancel'),
    path('success/',connection.success,name='success'),
    path('send-mail/',views.send_mail_,name='send_mail'),
]
