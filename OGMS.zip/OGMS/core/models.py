from django.db import models
from datetime import datetime
# Create your models here.
class Contact(models.Model):
    name=models.CharField(max_length=50,default='')
    email=models.EmailField(max_length=50,default='')
    phone=models.CharField(max_length=11,default='')
    msg=models.CharField(max_length=200,default='')
    send_date=models.DateField(default=datetime.today)