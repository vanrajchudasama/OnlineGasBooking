from django.urls import path
from . import views

app_name='Core'
urlpatterns = [
    path('',views.home,name='home'),
    path('contact/',views.contact,name='contact'),
    path('aboutus/',views.about,name='about'),
    
]
