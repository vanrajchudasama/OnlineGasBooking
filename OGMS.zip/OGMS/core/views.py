from django.shortcuts import render
from .forms import ContactForm
from .models import Contact
from django.contrib import messages
from django.shortcuts import render,HttpResponseRedirect
# Create your views here.
def home(request):
    
    return render(request,'core/index.html')
def contact(request):
    if request.method=='POST':
        contact_form=ContactForm(request.POST)
        if contact_form.is_valid():
            name=contact_form.cleaned_data['name']
            email=contact_form.cleaned_data['email']
            phone=contact_form.cleaned_data['phone']
            msg=contact_form.cleaned_data['msg']
            contact=Contact.objects.create(name=name,email=email,phone=phone,msg=msg)
            messages.success(request,'Message send Success...!')
            contact_form=ContactForm()
            return HttpResponseRedirect('/contact')
            
    else:
        contact_form=ContactForm()
    return render(request,'core/contact.html',{'contact_form':contact_form})
def about(request):
    return render(request,'core/about.html')